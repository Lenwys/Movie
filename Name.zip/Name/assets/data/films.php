<?php
// Film data storage
$films = [
    [
        'id' => 1,
        'title' => 'ocean-adventure',
        'display_title' => 'Ocean Adventure',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'Explore the mysterious depths of the ocean in this thrilling adventure.',
        'duration' => '1:42:15',
        'year' => '2023',
    ],
    [
        'id' => 2,
        'title' => 'space-journey',
        'display_title' => 'Space Journey',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'A journey through the cosmos revealing the wonders of our universe.',
        'duration' => '2:10:30',
        'year' => '2024',
    ],
    [
        'id' => 3,
        'title' => 'mystery-island',
        'display_title' => 'Mystery Island',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'A group of explorers discover a hidden island with ancient secrets.',
        'duration' => '1:58:45',
        'year' => '2022',
    ],
    [
        'id' => 4,
        'title' => 'digital-realm',
        'display_title' => 'Digital Realm',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'Enter a virtual world where nothing is as it seems.',
        'duration' => '2:15:20',
        'year' => '2024',
    ],
    [
        'id' => 5,
        'title' => 'ancient-legends',
        'display_title' => 'Ancient Legends',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'Discover the truth behind myths and legends from around the world.',
        'duration' => '1:48:30',
        'year' => '2023',
    ],
    [
        'id' => 6,
        'title' => 'urban-tales',
        'display_title' => 'Urban Tales',
        'embed_url' => 'https://jumpshare.com/embed/keY3M09T2lpdJgMT9Ajl',
        'thumbnail' => 'https://via.placeholder.com/300x200',
        'description' => 'Stories from the city that never sleeps, revealing its hidden secrets.',
        'duration' => '2:05:10',
        'year' => '2024',
    ],
];

// Function to get film by title
function getFilmByTitle($title) {
    global $films;
    foreach ($films as $film) {
        if ($film['title'] == $title) {
            return $film;
        }
    }
    return null;
}
