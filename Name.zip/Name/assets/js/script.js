document.addEventListener('DOMContentLoaded', function() {
    // Initialize search functionality
    const searchInput = document.querySelector('.search-box input');
    const searchButton = document.querySelector('.search-box button');
    
    if (searchButton && searchInput) {
        searchButton.addEventListener('click', function() {
            performSearch(searchInput.value);
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch(searchInput.value);
            }
        });
    }
    
    // Function to perform search
    function performSearch(query) {
        if (!query.trim()) return;
        
        // In a real application, this would redirect to a search results page
        // For now, we'll just log the search query
        console.log('Searching for:', query);
        alert('Search feature will be implemented in the future!');
    }
    
    // Video player functions
    const videoIframe = document.getElementById('js_video_iframe');
    if (videoIframe) {
        // Track when video is loaded
        videoIframe.addEventListener('load', function() {
            console.log('Video loaded successfully');
        });
    }
    
    // Add smooth scrolling for all links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add lazy loading for images (modern browsers support this natively)
    document.querySelectorAll('img').forEach(img => {
        img.setAttribute('loading', 'lazy');
    });
    
    // Responsive navigation for mobile
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.addEventListener('click', function(e) {
            if (window.innerWidth < 768) {
                const navList = document.querySelector('nav ul');
                if (navList) {
                    navList.classList.toggle('show');
                }
            }
        });
    }
});
